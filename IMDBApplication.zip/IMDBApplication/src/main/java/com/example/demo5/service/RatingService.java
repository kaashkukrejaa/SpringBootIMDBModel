package com.example.demo5.service;

public interface RatingService {
    void rateFilm(Long userId, Long filmId, Float ratingValue);
}
